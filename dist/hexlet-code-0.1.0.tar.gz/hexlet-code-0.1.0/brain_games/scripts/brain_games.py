#!/usr/bin/env python3
from brain_games import cli


def main():
    print('Welcome to the Brain games!')
    

if __name__ == '__main__':
    main()
    cli.welcome_user()
