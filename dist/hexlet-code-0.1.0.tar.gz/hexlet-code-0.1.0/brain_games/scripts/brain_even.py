#!/usr/bin/env python3
from brain_games import game

def main():
    return game.logic()
    


if __name__ == '__main__':
    main()
    
