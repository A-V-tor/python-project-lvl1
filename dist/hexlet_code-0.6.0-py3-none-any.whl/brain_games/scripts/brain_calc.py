#!/usr/bin/env python3
from brain_games.games import game


def main():
    return game.logic_calc()


if __name__ == '__main__':
    main()
