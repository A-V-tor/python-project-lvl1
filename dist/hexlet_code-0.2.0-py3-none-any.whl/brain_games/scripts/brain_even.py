#!/usr/bin/env python3
from brain_games import game



if __name__ == '__main__':
    game.logic()
    
